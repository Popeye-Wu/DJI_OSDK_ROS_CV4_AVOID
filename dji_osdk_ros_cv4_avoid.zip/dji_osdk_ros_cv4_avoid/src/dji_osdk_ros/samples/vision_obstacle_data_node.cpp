// INCLUDE

#include <dji_osdk_ros/ObstacleInfo.h>

#include <ros/ros.h>
#include <dji_osdk_ros/dji_vehicle_node.h>
#include <dji_osdk_ros/vehicle_wrapper.h>

void obstacleDisCallback(const dji_osdk_ros::ObstacleInfo::ConstPtr& avoidData)
{
	if (avoidData->down_health == 1)
	{
		ROS_INFO("Current down distance is :%d m", avoidData->down);
	}
	
	if (avoidData->front_health == 1)
	{
		ROS_INFO("Current front distance is :%d m", avoidData->front);
	}

	if (avoidData->right_health == 1)
	{
		ROS_INFO("Current right distance is :%d m", avoidData->right);
	}

	if (avoidData->left_health == 1)
	{
		ROS_INFO("Current left distance is :%d m", avoidData->left);
	}

	if (avoidData->up_health == 1)
	{
		ROS_INFO("Current up distance is :%d m", avoidData->up);
	}
}

int main(int argc, char** argv) {
  ros::init(argc, argv, "vision_obstacle_data_node");
  
  ros:: NodeHandle hn;

  ros::Subscriber obstacel_dis_sub = hn.subscribe("dji_osdk_ros/obstacle_info", 10, obstacleDisCallback);

  ros::Rate loop_rate(5);
  
  while (ros::ok())
  {
  
  ros::spinOnce();
  loop_rate.sleep();

  }

  return 0;

}

