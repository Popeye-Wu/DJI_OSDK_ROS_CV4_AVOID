/*******************************************************************************
 *   Copyright (C) 2022 Concordia NAVlab. All rights reserved.
 *
 *   @Filename: GetCurrentUltrasoundAltitude.cpp
 *
 *   @Author: XIAOBO WU
 *
 *   @Email: 2015097272@qq.com
 *
 *   @Date: 2022-01-13
 *
 *   @Description:
 *
 *******************************************************************************/

#include <sensor_msgs/NavSatFix.h>
/*
#include <forest_fire_detection_system/include/tools/PositionHelper.hpp>
#include <forest_fire_detection_system/tools/PrintControl/FileWritter.hpp>
#include <forest_fire_detection_system/tools/SystemLib.hpp>
*/
#include <ros/ros.h>
#include <dji_osdk_ros/dji_vehicle_node.h>
#include <dji_osdk_ros/vehicle_wrapper.h>

void ultrasoundDisCallback(const std_msgs::Float32::ConstPtr& dis)
{

ROS_INFO("Current distance between vechile and ground is: %f, dis");

}

int main(int argc, char** argv) {
  ros::init(argc, argv, "get_current_ultrasound_altitude_node");
  
  ros:: NodeHandle hn;

  ros::Subscriber ultraground_dis_sub = hn.subscribe("dji_osdk_ros/height_above_takeoff", 10, ultrasoundDisCallback);
  ros::Rate loop_rate(10);
  
  while (ros::ok())
  {
  
  ros::spinOnce();
  loop_rate.sleep();

  }
  
  return 0;

} 
/*
  FFDS::TOOLS::PositionHelper posHelper;

  sensor_msgs::NavSatFix gps = posHelper.getAverageGPS(average_times);
  PRINT_INFO(
      "current GPS position under %d average times is lon: %.9f, lat: %.9f, "
      "alt: %.9f",
      average_times, gps.longitude, gps.latitude, gps.altitude);

  FFDS::TOOLS::FileWritter gpsWriter("fire_average_gps_pos.csv", 8);
  gpsWriter.new_open();
  gpsWriter.write("time_ms", "longitude", "latitude", "altitude");
  gpsWriter.write(FFDS::TOOLS::getSysTime(), gps.longitude, gps.latitude,
                  gps.altitude);
  gpsWriter.close();

  return 0;
}
*/
